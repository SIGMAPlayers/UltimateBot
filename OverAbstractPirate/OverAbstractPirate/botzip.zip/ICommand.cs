﻿using System.Collections.Generic;
using System.Linq;

namespace MyBot
{
    public interface ICommand
    {
        void ExecuteCommand();
    }
}
